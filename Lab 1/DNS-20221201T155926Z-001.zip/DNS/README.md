############# Báo cáo DNS #############

- Các thành viên trong nhóm gồm có:
  - 3119410330 - Tăng Trình Quang
  - 3119410378 - Võ Lê Tân
  - 3119410426 - Trần Minh Thức
  - 3119410418 - Trần Gia Thuận
  - 3120410485 - Quản Xuân Thắng
  - 3120410492 - Nguyễn Chí Thiện
- Giảng viên hướng dẫn: ThS. Lương Minh Huấn
- Hoàn tất các công việc:
  - Báo cáo lý thuyết + thực hành DNS (demo)
  - Báo cáo Auto Script
